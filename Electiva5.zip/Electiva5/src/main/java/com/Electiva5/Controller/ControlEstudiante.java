package com.Electiva5.Controller;

import com.Electiva5.Entity.Estudiante;
import com.Electiva5.Services.ServicioEstudiante;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController

public class ControlEstudiante {
    ServicioEstudiante ser1 = new ServicioEstudiante();
    Estudiante est1;
    public ControlEstudiante(){
        this.est1 = this.ser1.getEstudiante();
    }
    @GetMapping("/prueba")
    public Estudiante prueba(){

        return this.est1;
    }
}
