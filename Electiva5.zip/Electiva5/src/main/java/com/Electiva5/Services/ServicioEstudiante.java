package com.Electiva5.Services;

import com.Electiva5.Entity.Estudiante;

public class ServicioEstudiante {
    Estudiante estudiante;
    public ServicioEstudiante(){

         this.estudiante = new Estudiante("Jesus","Montiel","1047495433","monti@gmail.com","13 de junio");

    }

    public Estudiante getEstudiante() {
        return this.estudiante;
    }
}
