package com.Electiva5;

import com.Electiva5.Entity.Estudiante;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Electiva5Application {

	public static void main(String[] args) {
		SpringApplication.run(Electiva5Application.class, args);

		Estudiante estudiante = new Estudiante("Jesus","Montiel","1047495433","monti@gmail.com","13 de junio");
		System.out.print(estudiante.toString());
	}

}
